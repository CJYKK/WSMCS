# 概述  

这里是繁星之望服务器，英文名WSMCS，始于2023年3月26日，是一个生电养老服，服务器需要正版，需要白名单。

服主：**FrankHymC**&**Tom_Chicken**

诚招各位萌新和大佬前来游玩！

文档编写完善：**FrankHymC**&**Tom_Chicken**

网站搭建：**ApartTUSITU**

服务器logo:![FHC_TC.png](https://s2.loli.net/2023/01/18/Z2mP7EeBDNhjzRU.png)

